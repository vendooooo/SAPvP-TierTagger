package com.sapvp.tiertagger.mixin;

import com.sapvp.tiertagger.render.NametagTextFormatter;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin {
	@Inject(method = "updateRenderState", at = @At("RETURN"), require = 0)
	private void sapvp$applyTierTagToPlayerLike(class_11890 player, class_10055 state, float tickProgress, CallbackInfo ci) {
		sapvp$applyTierTag(player.method_5667(), player.method_5477().getString(), player.method_5477(), state);
	}

	@Unique
	private static void sapvp$applyTierTag(java.util.UUID uuid, String fallbackName, class_2561 fallbackText, class_10055 state) {
		class_2561 baseText = state.field_53337;
		boolean usingCustomDisplayName = baseText != null;
		if (baseText == null) {
			baseText = state.field_53525;
		}
		if (baseText == null) {
			baseText = fallbackText;
		}

		class_2561 formatted = NametagTextFormatter.format(uuid, fallbackName, baseText);
		if (usingCustomDisplayName) {
			state.field_53337 = formatted;
			state.field_53525 = null;
			return;
		}

		state.field_53525 = formatted;
	}
}
