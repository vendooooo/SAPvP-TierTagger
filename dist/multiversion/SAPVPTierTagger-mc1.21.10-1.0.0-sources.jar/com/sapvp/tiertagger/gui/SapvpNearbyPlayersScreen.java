package com.sapvp.tiertagger.gui;

import com.sapvp.tiertagger.SAPVPTierTaggerClient;
import com.sapvp.tiertagger.model.SapvpPlayerProfile;
import com.sapvp.tiertagger.service.PlayerLookupTarget;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_742;

public final class SapvpNearbyPlayersScreen extends class_437 {
	private final class_437 parent;
	private final List<class_4185> playerButtons = new ArrayList<>();
	private final List<class_742> visiblePlayers = new ArrayList<>();
	private final List<class_742> players = new ArrayList<>();
	private int page;

	public SapvpNearbyPlayersScreen(class_437 parent) {
		super(class_2561.method_43470("Jogadores proximos"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		for (int i = 0; i < 10; i++) {
			final int buttonIndex = i;
			visiblePlayers.add(null);
			class_4185 button = method_37063(class_4185.method_46430(class_2561.method_43470(""), pressed -> {
				class_742 player = visiblePlayers.get(buttonIndex);
				if (player != null) {
					SAPVPTierTaggerClient.openProfile(PlayerLookupTarget.forUuid(player.method_5667(), player.method_5477().getString()));
				}
			}).method_46434(30, 46 + (i * 22), this.field_22789 - 60, 20).method_46431());
			playerButtons.add(button);
		}

		method_37063(class_4185.method_46430(class_2561.method_43470("Anterior"), button -> {
			if (page > 0) {
				page--;
				refreshPlayers();
			}
		}).method_46434(this.field_22789 / 2 - 155, this.field_22790 - 28, 74, 20)
			.method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Proximo"), button -> {
			if ((page + 1) * 10 < players.size()) {
				page++;
				refreshPlayers();
			}
		}).method_46434(this.field_22789 / 2 - 77, this.field_22790 - 28, 74, 20)
			.method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Atualizar"), button -> refreshPlayers())
			.method_46434(this.field_22789 / 2 + 1, this.field_22790 - 28, 74, 20)
			.method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Voltar"), button -> method_25419())
			.method_46434(this.field_22789 / 2 + 79, this.field_22790 - 28, 74, 20)
			.method_46431());
		refreshPlayers();
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(parent);
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		renderSafeBackground(context);
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 16, 0xFFFFFFFF);
		context.method_27534(this.field_22793, class_2561.method_43470("Clique em um jogador para abrir o painel SAPVP."), this.field_22789 / 2, 28, 0xFF9CA3AF);

		if (players.isEmpty()) {
			context.method_27534(this.field_22793, class_2561.method_43470("Nenhum jogador encontrado por perto."), this.field_22789 / 2, 60, 0xFFFFD54A);
			super.method_25394(context, mouseX, mouseY, delta);
			return;
		}

		context.method_27534(this.field_22793, class_2561.method_43470("Pagina " + (page + 1)), this.field_22789 / 2, this.field_22790 - 40, 0xFFA6ADC8);

		super.method_25394(context, mouseX, mouseY, delta);
	}

	private void renderSafeBackground(class_332 context) {
		context.method_25296(0, 0, this.field_22789, this.field_22790, 0xF010131A, 0xF0202B38);
		context.method_25294(20, 38, this.field_22789 - 20, this.field_22790 - 36, 0x55303A48);
	}

	private void refreshPlayers() {
		players.clear();
		if (this.field_22787 == null || this.field_22787.field_1687 == null || this.field_22787.field_1724 == null) {
			return;
		}
		players.addAll(this.field_22787.field_1687.method_18456().stream()
			.filter(player -> player != this.field_22787.field_1724)
			.sorted(Comparator.comparingDouble(player -> player.method_5739(this.field_22787.field_1724)))
			.toList());

		int firstIndex = page * 10;
		if (firstIndex >= players.size() && page > 0) {
			page = Math.max(0, (players.size() - 1) / 10);
			firstIndex = page * 10;
		}

		for (int index = 0; index < playerButtons.size(); index++) {
			class_4185 button = playerButtons.get(index);
			int playerIndex = firstIndex + index;
			if (playerIndex >= players.size()) {
				visiblePlayers.set(index, null);
				button.field_22764 = false;
				button.field_22763 = false;
				continue;
			}

			class_742 player = players.get(playerIndex);
			visiblePlayers.set(index, player);
			Optional<SapvpPlayerProfile> profile = SAPVPTierTaggerClient.profileService().getCached(player.method_5667());
			SAPVPTierTaggerClient.profileService().requestProfile(player.method_5667(), player.method_5477().getString());
			String label = player.method_5477().getString()
				+ "  |  "
				+ profile.map(SapvpPlayerProfile::bestTierShort).orElse("...")
				+ "  |  "
				+ String.format("%.1fm", Math.sqrt(player.method_5739(this.field_22787.field_1724)))
				+ "  |  "
				+ profile.map(SapvpPlayerProfile::countryCodeOrFallback).orElse("--");

			button.method_25355(class_2561.method_43470(label));
			button.field_22764 = true;
			button.field_22763 = true;
		}
	}
}
