package com.sapvp.tiertagger.gui;

import com.sapvp.tiertagger.SAPVPTierTaggerClient;
import com.sapvp.tiertagger.config.SapvpTierTaggerConfig;
import com.sapvp.tiertagger.util.ModeIconStyleOption;
import com.sapvp.tiertagger.util.ModeVisuals;
import com.sapvp.tiertagger.util.NametagModeOption;
import com.sapvp.tiertagger.util.NametagSideOption;
import com.sapvp.tiertagger.util.TierLabel;
import com.sapvp.tiertagger.util.TierLabels;
import com.sapvp.tiertagger.util.TierVisuals;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import org.joml.Matrix3x2fStack;

public final class SapvpConfigHomeScreen extends class_437 {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int TEXT = 0xFFD7DCEF;
    private static final int MUTED = 0xFF92A0B5;
    private static final int PANEL = 0xF00D141D;
    private static final int SECTION = 0xCC121B27;
    private static final int SURFACE = 0xB1161E2A;
    private static final int BORDER = 0xB92A3648;
    private static final int DIVIDER = 0x26334255;
    private static final int CYAN = 0xFF6FE6E1;
    private static final int GREEN = 0xFFA6E3A1;
    private static final int GOLD = 0xFFFFD166;
    private static final int RED = 0xFFF38BA8;
    private static final int BLUE = 0xFF89B4FA;
    private static final int OVERLAY_TOP = 0x74030A11;
    private static final int OVERLAY_BOTTOM = 0xB0050810;

    private final class_437 parent;

    private class_4185 enabledButton;
    private class_4185 nametagButton;
    private class_4185 modeIconButton;
    private class_4185 sideButton;
    private class_4185 modeButton;
    private class_4185 styleButton;

    public SapvpConfigHomeScreen(class_437 parent) {
        super(class_2561.method_43470("SAPVP Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int x = panelX();
        int y = panelY();
        int controlsX = x + 18;
        int controlsY = y + 214;
        int controlsWidth = panelWidth() - 36;
        int columnGap = 12;
        int columnWidth = (controlsWidth - columnGap) / 2;
        int rowGap = 6;
        int rowHeight = 42;
        int quickButtonWidth = 118;

        enabledButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> toggleEnabled())
            .method_46434(controlsX + columnWidth - quickButtonWidth - 10, controlsY + 11, quickButtonWidth, 20)
            .method_46431());
        nametagButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> toggleNametag())
            .method_46434(controlsX + columnWidth + columnGap + columnWidth - quickButtonWidth - 10, controlsY + 11, quickButtonWidth, 20)
            .method_46431());
        modeIconButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> toggleModeIcon())
            .method_46434(controlsX + columnWidth - quickButtonWidth - 10, controlsY + rowHeight + rowGap + 11, quickButtonWidth, 20)
            .method_46431());

        sideButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> cycleSide())
            .method_46434(controlsX + columnWidth + columnGap + columnWidth - quickButtonWidth - 10, controlsY + rowHeight + rowGap + 11, quickButtonWidth, 20)
            .method_46431());
        modeButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> cycleMode())
            .method_46434(controlsX + columnWidth - quickButtonWidth - 10, controlsY + (rowHeight + rowGap) * 2 + 11, quickButtonWidth, 20)
            .method_46431());
        styleButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> cycleStyle())
            .method_46434(controlsX + columnWidth + columnGap + columnWidth - quickButtonWidth - 10, controlsY + (rowHeight + rowGap) * 2 + 11, quickButtonWidth, 20)
            .method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Editor completo"), button -> this.field_22787.method_1507(SapvpConfigScreen.createAdvanced(this)))
            .method_46434(x + panelWidth() - 216, y + panelHeight() - 30, 128, 20)
            .method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Voltar"), button -> method_25419())
            .method_46434(x + panelWidth() - 80, y + panelHeight() - 30, 62, 20)
            .method_46431());

        refreshButtons();
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        renderBackdrop(context);

        int x = panelX();
        int y = panelY();
        int width = panelWidth();
        int height = panelHeight();
        int accent = SAPVPTierTaggerClient.config().enabled ? CYAN : RED;

        drawShell(context, x, y, width, height, accent);
        drawHeader(context, x + 18, y + 16, width - 36);
        drawPreviewCard(context, x + 18, y + 72, 244, 120);
        drawStatusCard(context, x + 274, y + 72, width - 292, 120);
        drawControlsBoard(context, x + 18, y + 204, width - 36, 140);
        drawFooterRail(context, x + 18, y + height - 38, width - 36, 26);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void renderBackdrop(class_332 context) {
        context.method_25296(0, 0, this.field_22789, this.field_22790, OVERLAY_TOP, OVERLAY_BOTTOM);
    }

    private void drawShell(class_332 context, int x, int y, int width, int height, int accent) {
        context.method_25294(x - 10, y - 10, x + width + 10, y + height + 10, 0x24000000);
        context.method_25294(x - 2, y - 2, x + width + 2, y + height + 2, BORDER);
        context.method_25294(x, y, x + width, y + height, PANEL);
        context.method_25296(x, y, x + width, y + 54, tint(accent, 0x30), 0x00000000);
        context.method_25294(x, y, x + 4, y + height, tint(accent, 0x64));
        context.method_25294(x + 18, y + 56, x + width - 18, y + 57, DIVIDER);
    }

    private void drawHeader(class_332 context, int x, int y, int width) {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        drawScaledText(context, "SETTINGS.", x, y + 1, 1.34F, WHITE);
        context.method_27535(this.field_22793, class_2561.method_43470("Ajuste a nametag e o visual sem entrar no editor completo."), x, y + 23, MUTED);
        context.method_27535(this.field_22793, class_2561.method_43470("Modo atual: " + NametagModeOption.fromModeId(config.nametagMode).displayLabel() + "  |  Lado: " + NametagSideOption.fromId(config.nametagSide).label()), x, y + 38, TEXT);

        String status = config.enabled ? "Ativo" : "Desativado";
        int statusColor = config.enabled ? GREEN : RED;
        int badgeWidth = this.field_22793.method_1727(status) + 18;
        int badgeX = x + width - badgeWidth;
        context.method_25294(badgeX, y + 2, badgeX + badgeWidth, y + 20, tint(statusColor, 0x24));
        context.method_25294(badgeX, y + 2, badgeX + 3, y + 20, statusColor);
        context.method_27535(this.field_22793, class_2561.method_43470(status), badgeX + 9, y + 7, statusColor);
    }

    private void drawPreviewCard(class_332 context, int x, int y, int width, int height) {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        context.method_25294(x, y, x + width, y + height, SECTION);
        context.method_25296(x, y, x + width, y + 28, 0x221D3042, 0x00000000);
        drawScaledText(context, "NAMETAG.", x + 12, y + 8, 1.10F, WHITE);
        context.method_27535(this.field_22793, class_2561.method_43470("Preview instantaneo da tag no jogo."), x + 12, y + 24, MUTED);

        int previewX = x + 12;
        int previewY = y + 46;
        int previewWidth = width - 24;
        context.method_25294(previewX, previewY, previewX + previewWidth, previewY + 38, SURFACE);
        context.method_25294(previewX, previewY, previewX + 4, previewY + 38, tint(CYAN, 0xC0));

        class_5250 preview = buildPreviewNametag();
        int textWidth = this.field_22793.method_27525(preview);
        int centeredX = previewX + Math.max(10, (previewWidth - textWidth) / 2);
        context.method_27535(this.field_22793, preview, centeredX, previewY + 14, WHITE);

        context.method_27535(this.field_22793, class_2561.method_43470("Distancia: " + config.maxRenderDistance + " blocos"), x + 12, y + 94, TEXT);
        context.method_27535(this.field_22793, class_2561.method_43470("Formato: " + config.nametagFormat), x + 12, y + 108, TEXT);
    }

    private void drawStatusCard(class_332 context, int x, int y, int width, int height) {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        context.method_25294(x, y, x + width, y + height, SECTION);
        context.method_25296(x, y, x + width, y + 28, 0x22162B3B, 0x00000000);
        drawScaledText(context, "OVERVIEW.", x + 12, y + 8, 1.10F, WHITE);
        context.method_27535(this.field_22793, class_2561.method_43470("Resumo rapido do estado atual."), x + 12, y + 24, MUTED);

        int metricY = y + 48;
        int colGap = 10;
        int metricWidth = Math.max(92, (width - 36) / 3);
        drawMiniMetric(context, x + 12, metricY, metricWidth, 34, "Cache", config.cacheCooldownSeconds + "s", CYAN);
        drawMiniMetric(context, x + 12 + metricWidth + colGap, metricY, metricWidth, 34, "Raio", config.requestRadius + "m", BLUE);
        drawMiniMetric(context, x + 12 + (metricWidth + colGap) * 2, metricY, width - (metricWidth + colGap) * 2 - 24, 34, "Track", Integer.toString(config.maxTrackedPlayers), GOLD);

        context.method_27535(this.field_22793, class_2561.method_43470("Paleta dos tiers"), x + 12, y + 92, MUTED);
        drawTierPalette(context, x + 12, y + 106);
    }

    private void drawControlsBoard(class_332 context, int x, int y, int width, int height) {
        context.method_25294(x, y, x + width, y + height, SECTION);
        context.method_25296(x, y, x + width, y + 24, 0x201A2636, 0x00000000);
        drawScaledText(context, "QUICK ACTIONS.", x + 12, y + 7, 1.06F, WHITE);
        context.method_27535(this.field_22793, class_2561.method_43470("Cada linha controla uma parte do mod sem sobrepor a interface."), x + 126, y + 10, MUTED);

        int columnGap = 12;
        int columnWidth = (width - columnGap) / 2;
        int rowHeight = 42;
        int rowGap = 6;

        drawSettingRow(context, x, y + 26, columnWidth, "Modulo", "Liga o mod inteiro.", CYAN);
        drawSettingRow(context, x + columnWidth + columnGap, y + 26, columnWidth, "Nametag", "Mostra ou oculta as tags.", CYAN);
        drawSettingRow(context, x, y + 26 + rowHeight + rowGap, columnWidth, "Icone do modo", "Exibe o icone antes do tier.", BLUE);
        drawSettingRow(context, x + columnWidth + columnGap, y + 26 + rowHeight + rowGap, columnWidth, "Lado", "Antes ou depois do nick.", BLUE);
        drawSettingRow(context, x, y + 26 + (rowHeight + rowGap) * 2, columnWidth, "Modo", "Escolhe qual tier mostrar.", GOLD);
        drawSettingRow(context, x + columnWidth + columnGap, y + 26 + (rowHeight + rowGap) * 2, columnWidth, "Estilo", "SA Icons ou emoji.", GOLD);
    }

    private void drawSettingRow(class_332 context, int x, int y, int width, String title, String subtitle, int accent) {
        context.method_25294(x, y, x + width, y + 42, 0x1E101722);
        context.method_25294(x, y, x + 3, y + 42, accent);
        context.method_27535(this.field_22793, class_2561.method_43470(title), x + 10, y + 6, WHITE);
        context.method_27535(this.field_22793, class_2561.method_43470(subtitle), x + 10, y + 18, MUTED);
    }

    private void drawMiniMetric(class_332 context, int x, int y, int width, int height, String label, String value, int accent) {
        context.method_25294(x, y, x + width, y + height, SURFACE);
        context.method_25294(x, y, x + 4, y + height, tint(accent, 0xC0));
        context.method_27535(this.field_22793, class_2561.method_43470(label), x + 10, y + 8, MUTED);
        context.method_27535(this.field_22793, class_2561.method_43470(value), x + 10, y + 20, accent);
    }

    private void drawTierPalette(class_332 context, int x, int y) {
        int swatchWidth = 18;
        int gap = 6;
        int[] raws = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
        int drawX = x;
        for (int raw : raws) {
            TierLabel tier = TierLabels.fromRaw(raw);
            int color = TierVisuals.accentColor(tier);
            context.method_25294(drawX, y, drawX + swatchWidth, y + 10, TierVisuals.backgroundColor(tier));
            context.method_25294(drawX, y, drawX + 3, y + 10, color);
            drawX += swatchWidth + gap;
        }
    }

    private void drawFooterRail(class_332 context, int x, int y, int width, int height) {
        context.method_25294(x, y, x + width, y + height, 0x22111A24);
        context.method_25294(x, y, x + width, y + 1, DIVIDER);
        context.method_27535(this.field_22793, class_2561.method_43470("Use o editor completo para cores, cache e ajustes avancados."), x + 10, y + 8, MUTED);
    }

    private class_5250 buildPreviewNametag() {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        String previewMode = config.nametagMode == null ? "BEST" : config.nametagMode;
        previewMode = ModeVisuals.normalizeNametagMode(previewMode);
        if ("BEST".equals(previewMode)) {
            previewMode = "SWORD";
        }

        TierLabel tier = TierLabels.fromRaw(6);
        class_5250 prefix = class_2561.method_43473();
        if (config.showModeIconInNametag) {
            prefix.method_10852(previewIcon(previewMode));
            prefix.method_10852(class_2561.method_43470(" "));
        }
        prefix.method_10852(class_2561.method_43470(config.nametagFormat.replace("%tier%", tier.shortLabel()))
            .method_10862(class_2583.field_24360.method_36139(config.tierColorFor(tier) & 0x00FFFFFF)));

        class_5250 nick = class_2561.method_43470("Vendouzz")
            .method_10862(class_2583.field_24360.method_36139(config.nameColor & 0x00FFFFFF));
        class_5250 separator = class_2561.method_43470(" | ")
            .method_10862(class_2583.field_24360.method_36139(config.separatorColor & 0x00FFFFFF));

        if (NametagSideOption.fromId(config.nametagSide) == NametagSideOption.RIGHT) {
            return class_2561.method_43473().method_10852(nick).method_10852(separator).method_10852(prefix);
        }
        return class_2561.method_43473().method_10852(prefix).method_10852(separator).method_10852(nick);
    }

    private class_2561 previewIcon(String modeId) {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        if (ModeIconStyleOption.fromId(config.modeIconStyle) == ModeIconStyleOption.EMOJI) {
            return class_2561.method_43470(ModeVisuals.emoji(modeId)).method_10862(class_2583.field_24360.method_36139(config.modeIconColor & 0x00FFFFFF));
        }
        return class_2561.method_43470(ModeVisuals.iconGlyph(modeId)).method_10862(ModeVisuals.saIconStyle(config.modeIconColor));
    }

    private void toggleEnabled() {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        config.enabled = !config.enabled;
        commitChanges();
    }

    private void toggleNametag() {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        config.renderNametags = !config.renderNametags;
        commitChanges();
    }

    private void toggleModeIcon() {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        config.showModeIconInNametag = !config.showModeIconInNametag;
        commitChanges();
    }

    private void cycleSide() {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        config.nametagSide = NametagSideOption.fromId(config.nametagSide) == NametagSideOption.LEFT ? NametagSideOption.RIGHT.id() : NametagSideOption.LEFT.id();
        commitChanges();
    }

    private void cycleMode() {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        NametagModeOption[] values = NametagModeOption.values();
        NametagModeOption current = NametagModeOption.fromModeId(config.nametagMode);
        int next = (current.ordinal() + 1) % values.length;
        config.nametagMode = values[next].modeId();
        commitChanges();
    }

    private void cycleStyle() {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        config.modeIconStyle = ModeIconStyleOption.fromId(config.modeIconStyle) == ModeIconStyleOption.SA_ICONS
            ? ModeIconStyleOption.EMOJI.id()
            : ModeIconStyleOption.SA_ICONS.id();
        commitChanges();
    }

    private void commitChanges() {
        SAPVPTierTaggerClient.config().normalize();
        SAPVPTierTaggerClient.saveConfig();
        refreshButtons();
    }

    private void refreshButtons() {
        SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
        enabledButton.method_25355(toggleText("Modulo", config.enabled));
        nametagButton.method_25355(toggleText("Nametag", config.renderNametags));
        modeIconButton.method_25355(toggleText("Icone do modo", config.showModeIconInNametag));
        sideButton.method_25355(cycleText("Lado", NametagSideOption.fromId(config.nametagSide).label(), CYAN));
        modeButton.method_25355(cycleText("Modo", NametagModeOption.fromModeId(config.nametagMode).displayLabel(), GOLD));
        styleButton.method_25355(cycleText("Estilo", ModeIconStyleOption.fromId(config.modeIconStyle).label(), BLUE));
    }

    private class_2561 toggleText(String label, boolean enabled) {
        return class_2561.method_43473()
            .method_10852(class_2561.method_43470(label + ": ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470(enabled ? "ON" : "OFF").method_27692(enabled ? class_124.field_1060 : class_124.field_1061));
    }

    private class_2561 cycleText(String label, String value, int color) {
        return class_2561.method_43473()
            .method_10852(class_2561.method_43470(label + ": ").method_27692(class_124.field_1080))
            .method_10852(class_2561.method_43470(value).method_10862(class_2583.field_24360.method_36139(color & 0x00FFFFFF)));
    }

    private void drawScaledText(class_332 context, String text, int x, int y, float scale, int color) {
        Matrix3x2fStack matrices = context.method_51448();
        matrices.pushMatrix();
        matrices.translate(x, y);
        matrices.scale(scale, scale);
        context.method_27535(this.field_22793, class_2561.method_43470(text), 0, 0, color);
        matrices.popMatrix();
    }

    private int panelWidth() {
        return Math.min(630, this.field_22789 - 44);
    }

    private int panelHeight() {
        return Math.min(404, this.field_22790 - 32);
    }

    private int panelX() {
        return (this.field_22789 - panelWidth()) / 2;
    }

    private int panelY() {
        return (this.field_22790 - panelHeight()) / 2;
    }

    private static int tint(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }
}
