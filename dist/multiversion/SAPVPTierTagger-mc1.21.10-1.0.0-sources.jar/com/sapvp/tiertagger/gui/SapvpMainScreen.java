package com.sapvp.tiertagger.gui;

import com.sapvp.tiertagger.SAPVPTierTaggerClient;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class SapvpMainScreen extends class_437 {
	private final class_437 parent;
	private class_342 nameField;

	public SapvpMainScreen(class_437 parent) {
		super(class_2561.method_43470("SAPVP Tier Tagger"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		int centerX = this.field_22789 / 2;
		int startY = this.field_22790 / 2 - 70;

		nameField = new class_342(this.field_22793, centerX - 100, startY, 200, 20, class_2561.method_43470("Nick SAPVP"));
		nameField.method_47404(class_2561.method_43470("Digite um nick da SAPVP"));
		method_25429(nameField);
		method_48265(nameField);

		method_37063(class_4185.method_46430(class_2561.method_43470("Buscar nick"), button -> searchByTypedName())
			.method_46434(centerX - 100, startY + 26, 200, 20)
			.method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Perfil do alvo"), button -> SAPVPTierTaggerClient.openLookTargetProfile(this.field_22787, true))
			.method_46434(centerX - 100, startY + 52, 200, 20)
			.method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Jogadores proximos"), button -> this.field_22787.method_1507(new SapvpNearbyPlayersScreen(this)))
			.method_46434(centerX - 100, startY + 78, 200, 20)
			.method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Configuracao"), button -> this.field_22787.method_1507(SapvpConfigScreen.create(this)))
			.method_46434(centerX - 100, startY + 104, 200, 20)
			.method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("Fechar"), button -> method_25419())
			.method_46434(centerX - 100, startY + 130, 200, 20)
			.method_46431());
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(parent);
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		renderSafeBackground(context);
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.field_22790 / 2 - 100, 0xFFFFFFFF);
		context.method_27534(this.field_22793, class_2561.method_43470("Abra perfis por nick, alvo ou lista de players proximos."), this.field_22789 / 2, this.field_22790 / 2 - 86, 0xFF9CA3AF);
		nameField.method_25394(context, mouseX, mouseY, delta);
		super.method_25394(context, mouseX, mouseY, delta);
	}

	private void renderSafeBackground(class_332 context) {
		context.method_25296(0, 0, this.field_22789, this.field_22790, 0xF010131A, 0xF0202B38);
		context.method_25294(this.field_22789 / 2 - 120, this.field_22790 / 2 - 110, this.field_22789 / 2 + 120, this.field_22790 / 2 + 92, 0x662A3442);
	}

	private void searchByTypedName() {
		String value = nameField.method_1882().trim();
		if (!value.isEmpty()) {
			SAPVPTierTaggerClient.openProfileByName(value);
		}
	}
}
