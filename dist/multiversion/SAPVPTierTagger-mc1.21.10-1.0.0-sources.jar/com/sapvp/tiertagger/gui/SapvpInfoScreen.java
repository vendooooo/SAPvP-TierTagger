package com.sapvp.tiertagger.gui;

import com.sapvp.tiertagger.SAPVPTierTaggerClient;
import com.sapvp.tiertagger.model.SapvpModeRanking;
import com.sapvp.tiertagger.model.SapvpPlayerProfile;
import com.sapvp.tiertagger.service.PlayerLookupTarget;
import com.sapvp.tiertagger.service.ProfileLookupState;
import com.sapvp.tiertagger.util.ModeVisuals;
import com.sapvp.tiertagger.util.TierVisuals;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2fStack;

import java.util.Comparator;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_640;
import net.minecraft.class_7532;
import net.minecraft.class_8685;

public final class SapvpInfoScreen extends class_437 {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int TEXT = 0xFFD8DEEF;
    private static final int MUTED = 0xFF92A0B5;
    private static final int PANEL = 0xF0091018;
    private static final int SECTION = 0xD0101722;
    private static final int SURFACE = 0xB1121A27;
    private static final int BORDER = 0xBB243247;
    private static final int DIVIDER = 0x2A31435A;
    private static final int CYAN = 0xFF63D7D8;
    private static final int GREEN = 0xFFA6E3A1;
    private static final int GOLD = 0xFFFFD166;
    private static final int BLUE = 0xFF6288E4;
    private static final int SILVER = 0xFFD8E2F0;
    private static final int BRONZE = 0xFFCF9368;
    private static final int RED = 0xFFF38BA8;
    private static final int OVERLAY_TOP = 0x76030810;
    private static final int OVERLAY_BOTTOM = 0xB4050810;

    private final class_437 parent;
    private final PlayerLookupTarget target;

    private int rankingScroll;
    private int rankingAreaX;
    private int rankingAreaY;
    private int rankingAreaWidth;
    private int rankingAreaHeight;

    public SapvpInfoScreen(class_437 parent, PlayerLookupTarget target) {
        super(class_2561.method_43470("SAPVP Profile"));
        this.parent = parent;
        this.target = target;
    }

    @Override
    protected void method_25426() {
        int x = panelX();
        int y = panelY();
        int footerY = y + panelHeight() - 30;
        int buttonWidth = 86;
        int gap = 8;
        int totalWidth = buttonWidth * 3 + gap * 2;
        int buttonsX = x + panelWidth() - 18 - totalWidth;

        method_37063(class_4185.method_46430(class_2561.method_43470("Voltar"), button -> method_25419())
            .method_46434(buttonsX, footerY, buttonWidth, 20)
            .method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Recarregar"), button -> forceRefresh())
            .method_46434(buttonsX + buttonWidth + gap, footerY, buttonWidth, 20)
            .method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Config"), button -> this.field_22787.method_1507(SapvpConfigScreen.create(this)))
            .method_46434(buttonsX + (buttonWidth + gap) * 2, footerY, buttonWidth, 20)
            .method_46431());

        forceRefresh();
    }

    @Override
    public void method_25393() {
        if (this.field_22787 == null) {
            return;
        }
        if (this.field_22787.field_1687 == null) {
            method_25419();
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        ProfileLookupState state = SAPVPTierTaggerClient.profileService().lookupState(target);
        if (state.profile().isEmpty() || !contains(mouseX, mouseY, rankingAreaX, rankingAreaY, rankingAreaWidth, rankingAreaHeight)) {
            return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
        }

        List<SapvpModeRanking> rankings = sortedRankings(state.profile().get().rankings());
        int maxScroll = maxRankingScroll(rankings, rankingAreaHeight);
        if (maxScroll <= 0) {
            return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
        }

        rankingScroll = clamp(rankingScroll - (int) Math.signum(verticalAmount), 0, maxScroll);
        return true;
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        renderBackdrop(context);

        int x = panelX();
        int y = panelY();
        int width = panelWidth();
        int height = panelHeight();
        int contentX = x + 18;
        int contentWidth = width - 36;

        ProfileLookupState state = SAPVPTierTaggerClient.profileService().lookupState(target);
        SapvpPlayerProfile profile = state.profile().orElse(null);
        int accent = profile != null ? TierVisuals.accentColor(profile.bestTier()) : CYAN;

        drawShell(context, x, y, width, height, accent);
        drawHeader(context, contentX, y + 16, contentWidth, profile, state);

        if (profile == null) {
            int footerTop = y + height - 50;
            drawLoadingPanel(context, contentX, y + 58, contentWidth, footerTop - (y + 58), state, accent);
            rankingAreaX = 0;
            rankingAreaY = 0;
            rankingAreaWidth = 0;
            rankingAreaHeight = 0;
            drawFooterRail(context, contentX, footerTop, contentWidth, 18);
            super.method_25394(context, mouseX, mouseY, delta);
            return;
        }

        int footerTop = y + height - 50;
        drawStatsRow(context, contentX, y + 58, contentWidth, profile);
        drawRankingsBoard(context, contentX, y + 112, contentWidth, footerTop - (y + 112), sortedRankings(profile.rankings()));
        drawFooterRail(context, contentX, footerTop, contentWidth, 18);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void renderBackdrop(class_332 context) {
        context.method_25296(0, 0, this.field_22789, this.field_22790, OVERLAY_TOP, OVERLAY_BOTTOM);
    }

    private void drawShell(class_332 context, int x, int y, int width, int height, int accent) {
        context.method_25294(x - 10, y - 10, x + width + 10, y + height + 10, 0x22000000);
        context.method_25294(x - 2, y - 2, x + width + 2, y + height + 2, BORDER);
        context.method_25294(x, y, x + width, y + height, PANEL);
        context.method_25296(x, y, x + width, y + 56, tint(accent, 0x30), 0x00000000);
        context.method_25294(x, y, x + 4, y + height, tint(accent, 0x6E));
        context.method_25294(x + 18, y + 58, x + width - 18, y + 59, DIVIDER);
        context.method_25296(x, y + height - 46, x + width, y + height, 0x00000000, 0x28050A10);
    }

    private void drawHeader(class_332 context, int x, int y, int width, @Nullable SapvpPlayerProfile profile, ProfileLookupState state) {
        int headSize = 34;
        drawPlayerHead(context, x, y, headSize, profile);

        int textX = x + headSize + 12;
        String title = profile != null ? profile.name() : fallbackTargetName();
        drawScaledText(context, title, textX, y + 1, 1.24F, WHITE);
        context.method_27535(this.field_22793, class_2561.method_43470("PROFILE."), textX, y + 22, MUTED);

        String status = profile != null ? "Loaded" : state.loading() ? "Consultando" : state.message() != null ? "Erro" : "Aguardando";
        int statusColor = profile != null ? GREEN : state.loading() ? GOLD : state.message() != null ? RED : CYAN;
        int badgeWidth = this.field_22793.method_1727(status) + 20;
        int badgeX = x + width - badgeWidth;
        context.method_25294(badgeX, y + 2, badgeX + badgeWidth, y + 22, tint(statusColor, 0x24));
        context.method_25294(badgeX, y + 2, badgeX + 3, y + 22, statusColor);
        context.method_27535(this.field_22793, class_2561.method_43470(status), badgeX + 10, y + 8, statusColor);
    }

    private void drawStatsRow(class_332 context, int x, int y, int width, SapvpPlayerProfile profile) {
        int gap = 10;
        int cardWidth = (width - gap) / 2;
        drawStatCard(context, x, y, cardWidth, 44, "PONTOS TOTAIS", Integer.toString(profile.points()), GOLD, 0x2B20170E, null, 0);

        PodiumStyle podium = podiumStyle(profile.globalRank());
        String topValue = profile.globalRank() > 0 ? "#" + profile.globalRank() : "Unranked";
        drawStatCard(
            context,
            x + cardWidth + gap,
            y,
            cardWidth,
            44,
            "RANK GLOBAL",
            topValue,
            podium != null ? podium.accent() : CYAN,
            podium != null ? podium.fill() : 0x25111A24,
            null,
            0
        );
    }

    private void drawStatCard(class_332 context, int x, int y, int width, int height, String label, String value, int valueColor, int fill, @Nullable String badge, int badgeColor) {
        context.method_25294(x, y, x + width, y + height, fill);
        context.method_25294(x, y, x + 4, y + height, tint(valueColor, 0xD0));
        context.method_27535(this.field_22793, class_2561.method_43470(label), x + 12, y + 8, MUTED);
        drawScaledText(context, value, x + 12, y + 22, 1.12F, valueColor);
        if (badge != null) {
            int badgeWidth = this.field_22793.method_1727(badge) + 16;
            context.method_25294(x + width - badgeWidth - 10, y + 8, x + width - 10, y + 24, tint(badgeColor, 0x20));
            context.method_27535(this.field_22793, class_2561.method_43470(badge), x + width - badgeWidth + 1, y + 13, badgeColor);
        }
    }

    private void drawLoadingPanel(class_332 context, int x, int y, int width, int height, ProfileLookupState state, int accent) {
        context.method_25294(x, y, x + width, y + height, SECTION);
        context.method_25296(x, y, x + width, y + 34, tint(accent, 0x22), 0x00000000);
        drawScaledText(context, "TIERS.", x + 12, y + 10, 1.14F, WHITE);
        context.method_27535(this.field_22793, class_2561.method_43470("Nick alvo: " + fallbackTargetName()), x + 12, y + 34, TEXT);

        String message = state.loading()
            ? "Consultando a API da SAPVP e preparando o perfil."
            : state.message() != null
                ? state.message()
                : "Aguardando retorno da API.";
        context.method_27535(this.field_22793, class_2561.method_43470(message), x + 12, y + 56, GOLD);
        context.method_27535(this.field_22793, class_2561.method_43470("Assim que os dados chegarem, a lista completa de tiers aparece aqui."), x + 12, y + 78, MUTED);
    }

    private void drawRankingsBoard(class_332 context, int x, int y, int width, int height, List<SapvpModeRanking> rankings) {
        context.method_25294(x, y, x + width, y + height, SECTION);
        context.method_25296(x, y, x + width, y + 30, 0x221A2735, 0x00000000);
        drawScaledText(context, "TIERS.", x + 12, y + 8, 1.14F, WHITE);

        String helper = rankings.isEmpty() ? "Sem modos" : rankings.size() + " modos";
        int helperWidth = this.field_22793.method_1727(helper) + 16;
        context.method_25294(x + width - helperWidth - 10, y + 7, x + width - 10, y + 23, SURFACE);
        context.method_27535(this.field_22793, class_2561.method_43470(helper), x + width - helperWidth + 1, y + 12, MUTED);

        int headerY = y + 30;
        context.method_25294(x + 10, headerY, x + width - 10, headerY + 18, 0x1B0F151E);
        context.method_27535(this.field_22793, class_2561.method_43470("Modo"), x + 40, headerY + 5, MUTED);

        int tierBoxWidth = 84;
        int tierColumnCenter = x + width - 114;
        int tierHeaderX = tierColumnCenter - (this.field_22793.method_1727("Tier") / 2);
        context.method_27535(this.field_22793, class_2561.method_43470("Tier"), tierHeaderX, headerY + 5, MUTED);

        int pointsHeaderX = x + width - 55;
        context.method_27535(this.field_22793, class_2561.method_43470("Pts"), pointsHeaderX, headerY + 5, MUTED);

        if (rankings.isEmpty()) {
            context.method_27535(this.field_22793, class_2561.method_43470("Nenhum tier encontrado para este jogador."), x + 14, headerY + 30, MUTED);
            rankingAreaX = 0;
            rankingAreaY = 0;
            rankingAreaWidth = 0;
            rankingAreaHeight = 0;
            return;
        }

        int listTop = headerY + 20;
        int listBottom = y + height - 10;
        int listHeight = listBottom - listTop;
        rankingAreaX = x + 10;
        rankingAreaY = listTop;
        rankingAreaWidth = width - 24;
        rankingAreaHeight = listHeight;

        int visibleRows = visibleRows(listHeight);
        int maxScroll = maxRankingScroll(rankings, listHeight);
        rankingScroll = clamp(rankingScroll, 0, maxScroll);

        context.method_44379(x + 10, listTop, x + width - 14, listBottom);
        int rowY = listTop;
        for (int index = rankingScroll; index < rankings.size() && index < rankingScroll + visibleRows; index++) {
            drawRankingRow(context, x + 10, rowY, width - 24, rankings.get(index), index - rankingScroll);
            rowY += 30;
        }
        context.method_44380();

        drawScrollBar(context, x + width - 10, listTop, 4, listHeight, rankings.size(), visibleRows);
    }

    private void drawRankingRow(class_332 context, int x, int y, int width, SapvpModeRanking ranking, int slotIndex) {
        int rowHeight = 32;
        int modeColor = ModeVisuals.accentColor(ranking.modeId());
        int tierColor = TierVisuals.accentColor(ranking.tier());
        int iconColor = SAPVPTierTaggerClient.config().modeIconColor;
        int background = slotIndex % 2 == 0 ? 0x2D101722 : 0x24101922;

        context.method_25294(x, y, x + width, y + rowHeight, background);
        context.method_25294(x, y, x + 3, y + rowHeight, modeColor);

        int iconBoxX = x + 8;
        context.method_25294(iconBoxX, y + 5, iconBoxX + 24, y + 27, tint(modeColor, 0x26));
        context.method_27534(this.field_22793, modeIconText(ranking, iconColor), iconBoxX + 12, y + 11, iconColor);

        int tierBoxWidth = 84;
        int tierBoxX = x + width - 156;
        int pointsRight = x + width - 14;
        int nameX = x + 42;
        int nameMaxWidth = Math.max(40, tierBoxX - nameX - 12);
        String modeName = this.field_22793.method_27523(ranking.displayName(), nameMaxWidth);

        context.method_27535(this.field_22793, class_2561.method_43470(modeName), nameX, y + 12, WHITE);

        context.method_25294(tierBoxX, y + 5, tierBoxX + tierBoxWidth, y + 27, TierVisuals.backgroundColor(ranking.tier()));
        context.method_25294(tierBoxX, y + 5, tierBoxX + 2, y + 27, tierColor);
        String tierText = ranking.tier().shortLabel();
        int tierTextX = tierBoxX + ((tierBoxWidth - this.field_22793.method_1727(tierText)) / 2);
        context.method_27535(this.field_22793, class_2561.method_43470(tierText), tierTextX, y + 12, tierColor);

        String points = ranking.points() + " pts";
        context.method_27535(this.field_22793, class_2561.method_43470(points), pointsRight - this.field_22793.method_1727(points), y + 12, GREEN);
    }

    private void drawFooterRail(class_332 context, int x, int y, int width, int height) {
        context.method_25294(x, y, x + width, y + height, 0x160D141C);
        context.method_25294(x, y, x + width, y + 1, DIVIDER);
    }

    private void drawScrollBar(class_332 context, int x, int y, int width, int height, int totalRows, int visibleRows) {
        context.method_25294(x, y, x + width, y + height, 0x220A0F15);
        if (totalRows <= visibleRows || totalRows <= 0) {
            return;
        }

        int maxScroll = Math.max(1, totalRows - visibleRows);
        int thumbHeight = Math.max(20, Math.round(height * (visibleRows / (float) totalRows)));
        int thumbTravel = Math.max(0, height - thumbHeight);
        int thumbY = y + Math.round((rankingScroll / (float) maxScroll) * thumbTravel);
        context.method_25294(x, thumbY, x + width, thumbY + thumbHeight, 0x88A6ADC8);
    }

    private void drawScaledText(class_332 context, String text, int x, int y, float scale, int color) {
        Matrix3x2fStack matrices = context.method_51448();
        matrices.pushMatrix();
        matrices.translate(x, y);
        matrices.scale(scale, scale);
        context.method_27535(this.field_22793, class_2561.method_43470(text), 0, 0, color);
        matrices.popMatrix();
    }

    private void forceRefresh() {
        rankingScroll = 0;
        if (target.uuid() != null) {
            SAPVPTierTaggerClient.profileService().requestProfile(target.uuid(), target.displayName());
        } else if (target.displayName() != null) {
            SAPVPTierTaggerClient.profileService().requestProfileByName(target.displayName());
        }
    }

    private List<SapvpModeRanking> sortedRankings(List<SapvpModeRanking> rankings) {
        return rankings.stream()
            .filter(ranking -> ModeVisuals.isSupportedTierlistMode(ranking.modeId()))
            .sorted(Comparator
                .comparingInt((SapvpModeRanking value) -> value.tier().raw()).reversed()
                .thenComparing(Comparator.comparingInt(SapvpModeRanking::points).reversed())
                .thenComparing(SapvpModeRanking::displayName, String.CASE_INSENSITIVE_ORDER))
            .toList();
    }

    private int visibleRows(int contentHeight) {
        return Math.max(1, contentHeight / 32);
    }

    private int maxRankingScroll(List<SapvpModeRanking> rankings, int contentHeight) {
        return Math.max(0, rankings.size() - visibleRows(contentHeight));
    }

    private String fallbackTargetName() {
        if (target.displayName() != null && !target.displayName().isBlank()) {
            return target.displayName();
        }
        return target.uuid() == null ? "Desconhecido" : target.uuid().toString();
    }

    private int panelWidth() {
        return Math.min(586, this.field_22789 - 48);
    }

    private int panelHeight() {
        return Math.min(398, this.field_22790 - 26);
    }

    private int panelX() {
        return (this.field_22789 - panelWidth()) / 2;
    }

    private int panelY() {
        return (this.field_22790 - panelHeight()) / 2;
    }

    private void drawPlayerHead(class_332 context, int x, int y, int size, @Nullable SapvpPlayerProfile profile) {
        if (this.field_22787 == null) {
            return;
        }

        context.method_25294(x - 2, y - 2, x + size + 2, y + size + 2, 0x44222B38);
        context.method_25294(x - 1, y - 1, x + size + 1, y + size + 1, 0xAA0E141D);

        class_8685 skinTextures = resolveLiveSkin(profile);
        if (skinTextures != null) {
            class_7532.method_52722(context, skinTextures, x, y, size);
            return;
        }

        class_2960 offlineSkin = SAPVPTierTaggerClient.avatarService().getOrRequestSkinTexture(this.field_22787, target, profile);
        if (offlineSkin != null) {
            class_7532.method_44445(context, offlineSkin, x, y, size, true, false, -1);
            return;
        }

        class_2960 headTexture = SAPVPTierTaggerClient.avatarService().getOrRequestHeadTexture(this.field_22787, target, profile);
        if (headTexture != null) {
            context.method_52706(class_10799.field_56883, headTexture, x, y, size, size);
            return;
        }

        context.method_25294(x, y, x + size, y + size, 0xFF1B2330);
        context.method_25294(x + 7, y + 8, x + 13, y + 14, WHITE);
        context.method_25294(x + 19, y + 8, x + 25, y + 14, WHITE);
        context.method_25294(x + 10, y + 20, x + 22, y + 23, MUTED);
    }

    private @Nullable class_8685 resolveLiveSkin(@Nullable SapvpPlayerProfile profile) {
        if (this.field_22787 == null || this.field_22787.method_1562() == null) {
            return null;
        }

        if (profile != null) {
            class_640 byUuid = this.field_22787.method_1562().method_2871(profile.uuid());
            if (byUuid != null) {
                return byUuid.method_52810();
            }
        }

        if (target.uuid() != null) {
            class_640 byTargetUuid = this.field_22787.method_1562().method_2871(target.uuid());
            if (byTargetUuid != null) {
                return byTargetUuid.method_52810();
            }
        }

        if (target.displayName() != null) {
            class_640 byName = this.field_22787.method_1562().method_2874(target.displayName());
            if (byName != null) {
                return byName.method_52810();
            }
        }

        return null;
    }

    private static String modeIcon(SapvpModeRanking ranking) {
        if ("EMOJI".equalsIgnoreCase(SAPVPTierTaggerClient.config().modeIconStyle)) {
            String emoji = ranking.emoji();
            if (emoji != null && !emoji.isBlank()) {
                return emoji;
            }
            return modeBadge(ranking.modeId());
        }
        return ModeVisuals.iconGlyph(ranking.modeId());
    }

    private static class_2561 modeIconText(SapvpModeRanking ranking, int iconColor) {
        String icon = modeIcon(ranking);
        if ("EMOJI".equalsIgnoreCase(SAPVPTierTaggerClient.config().modeIconStyle)) {
            return class_2561.method_43470(icon);
        }
        return class_2561.method_43470(icon).method_10862(ModeVisuals.saIconStyle(iconColor));
    }

    private static String modeBadge(String rawMode) {
        String normalized = ModeVisuals.normalize(rawMode);
        return switch (normalized) {
            case "SMP" -> "SM";
            case "SWORD" -> "SW";
            case "AXE" -> "AX";
            case "NETHERITE_POT", "NETHERITE_OP", "NETHERITE", "NETH_OP", "NETH_POT" -> "NP";
            case "CRYSTAL" -> "CR";
            case "MACE" -> "MC";
            default -> "??";
        };
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static boolean contains(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    private static int tint(int color, int alpha) {
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private static @Nullable PodiumStyle podiumStyle(int globalRank) {
        return switch (globalRank) {
            case 1 -> new PodiumStyle(GOLD, 0x3A2A1E08);
            case 2 -> new PodiumStyle(SILVER, 0x2E1A2028);
            case 3 -> new PodiumStyle(BRONZE, 0x34251610);
            default -> null;
        };
    }

    private record PodiumStyle(int accent, int fill) {
    }
}
