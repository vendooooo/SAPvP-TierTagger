package com.sapvp.tiertagger.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.sapvp.tiertagger.SAPVPTierTaggerClient;
import com.sapvp.tiertagger.api.SapvpApiClient.DebugLookupResult;
import com.sapvp.tiertagger.model.SapvpPlayerProfile;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7157;
import java.util.ArrayList;
import java.util.List;

public final class SapvpClientCommands {
	private SapvpClientCommands() {
	}

	public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher, class_7157 access) {
		var infoNode = ClientCommandManager.literal("info")
			.executes(context -> openLookTarget(context.getSource()))
			.then(ClientCommandManager.argument("player", StringArgumentType.greedyString())
				.executes(context -> openByName(
					context.getSource(),
					StringArgumentType.getString(context, "player")
				)));

		var configNode = ClientCommandManager.literal("config")
			.executes(context -> openConfig(context.getSource()));

		var nearbyNode = ClientCommandManager.literal("nearby")
			.executes(context -> openMainMenu(context.getSource()));

		var debugNode = ClientCommandManager.literal("debug")
			.then(ClientCommandManager.argument("player", StringArgumentType.greedyString())
				.executes(context -> debugByName(
					context.getSource(),
					StringArgumentType.getString(context, "player")
				)));

		dispatcher.register(ClientCommandManager.literal("sapvp")
			.executes(context -> openMainMenu(context.getSource()))
			.then(infoNode)
			.then(configNode)
			.then(nearbyNode)
			.then(debugNode));

		dispatcher.register(ClientCommandManager.literal("sapvptier")
			.executes(context -> openMainMenu(context.getSource()))
			.then(ClientCommandManager.literal("info")
				.executes(context -> openLookTarget(context.getSource()))
				.then(ClientCommandManager.argument("player", StringArgumentType.greedyString())
					.executes(context -> openByName(
						context.getSource(),
						StringArgumentType.getString(context, "player")
					))))
			.then(ClientCommandManager.literal("debug")
				.then(ClientCommandManager.argument("player", StringArgumentType.greedyString())
					.executes(context -> debugByName(context.getSource(), StringArgumentType.getString(context, "player")))))
			.then(ClientCommandManager.literal("config")
				.executes(context -> openConfig(context.getSource())))
			.then(ClientCommandManager.literal("player")
				.then(ClientCommandManager.argument("name", StringArgumentType.greedyString())
					.executes(context -> openByName(context.getSource(), StringArgumentType.getString(context, "name"))))));
	}

	private static int openMainMenu(FabricClientCommandSource source) {
		SAPVPTierTaggerClient.openMainMenu();
		source.sendFeedback(class_2561.method_43470("Abrindo menu SAPVP..."));
		return 1;
	}

	private static int openLookTarget(FabricClientCommandSource source) {
		SAPVPTierTaggerClient.openLookTargetProfile(class_310.method_1551(), true);
		return 1;
	}

	private static int openByName(FabricClientCommandSource source, String name) {
		if (name == null || name.isBlank()) {
			source.sendError(class_2561.method_43470("Use /sapvp info <nick>."));
			return 0;
		}
		SAPVPTierTaggerClient.openProfileByName(name.trim());
		source.sendFeedback(class_2561.method_43470("Consultando SAPVP para " + name.trim() + "..."));
		return 1;
	}

	private static int openConfig(FabricClientCommandSource source) {
		SAPVPTierTaggerClient.openConfigScreen();
		source.sendFeedback(class_2561.method_43470("Abrindo configuracao SAPVP..."));
		return 1;
	}

	private static int debugByName(FabricClientCommandSource source, String name) {
		String nickname = name == null ? "" : name.trim();
		if (nickname.isBlank()) {
			source.sendError(class_2561.method_43470("Use /sapvp debug <nick>."));
			return 0;
		}

		source.sendFeedback(class_2561.method_43470("Debug SAPVP para " + nickname + "..."));
		SAPVPTierTaggerClient.profileService().debugProfileByName(nickname)
			.thenAccept(result -> class_310.method_1551().execute(() -> sendDebugMessages(source, nickname, result)))
			.exceptionally(throwable -> {
				class_310.method_1551().execute(() ->
					source.sendError(class_2561.method_43470("Falha no debug SAPVP: " + throwable.getMessage()))
				);
				return null;
			});
		return 1;
	}

	private static void sendDebugMessages(FabricClientCommandSource source, String nickname, DebugLookupResult result) {
		source.sendFeedback(class_2561.method_43470("[SAPVP Debug] nick=" + nickname));
		source.sendFeedback(class_2561.method_43470("[SAPVP Debug] endpoint=" + result.path()));
		source.sendFeedback(class_2561.method_43470("[SAPVP Debug] status=" + result.statusCode()));

		SapvpPlayerProfile profile = result.profile();
		if (profile != null) {
			source.sendFeedback(class_2561.method_43470("[SAPVP Debug] parsed=" + profile.name()
				+ " | country=" + profile.countryCodeOrFallback()
				+ " | points=" + profile.points()
				+ " | global=#" + profile.globalRank()
				+ " | rankings=" + profile.rankings().size()));
		} else {
			source.sendFeedback(class_2561.method_43470("[SAPVP Debug] parsed=nenhum perfil valido"));
		}

		if (result.error() != null && !result.error().isBlank()) {
			source.sendError(class_2561.method_43470("[SAPVP Debug] erro=" + result.error()));
		}

		if (result.rawBody() != null && !result.rawBody().isBlank()) {
			for (String chunk : splitForChat("[SAPVP Debug] raw=" + result.rawBody(), 220)) {
				source.sendFeedback(class_2561.method_43470(chunk));
			}
		}
	}

	private static List<String> splitForChat(String text, int maxLength) {
		List<String> chunks = new ArrayList<>();
		for (int index = 0; index < text.length(); index += maxLength) {
			chunks.add(text.substring(index, Math.min(text.length(), index + maxLength)));
		}
		return chunks;
	}
}
