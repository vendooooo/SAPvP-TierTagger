package com.sapvp.tiertagger;

import com.sapvp.tiertagger.command.SapvpClientCommands;
import com.sapvp.tiertagger.compat.SapvpCompatibility;
import com.sapvp.tiertagger.config.ConfigManager;
import com.sapvp.tiertagger.config.SapvpTierTaggerConfig;
import com.sapvp.tiertagger.gui.SapvpConfigScreen;
import com.sapvp.tiertagger.gui.SapvpInfoScreen;
import com.sapvp.tiertagger.gui.SapvpMainScreen;
import com.sapvp.tiertagger.service.SapvpAvatarService;
import com.sapvp.tiertagger.service.PlayerLookupTarget;
import com.sapvp.tiertagger.service.SapvpProfileService;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_742;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.lwjgl.glfw.GLFW;

import java.util.UUID;

public final class SAPVPTierTaggerClient implements ClientModInitializer {
	public static final String MOD_ID = "sapvptiertagger";
	private static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static ConfigManager configManager;
	private static SapvpProfileService profileService;
	private static SapvpAvatarService avatarService;
	private static class_304 openProfileKey;
	private static class_304 openConfigKey;
	private static Runnable pendingUiAction;
	private static int pendingUiDelayTicks;

	@Override
	public void onInitializeClient() {
		SapvpCompatibility.logRuntimeStatus(LOGGER);

		configManager = new ConfigManager();
		configManager.load();
		profileService = new SapvpProfileService(configManager);
		avatarService = new SapvpAvatarService();

		openProfileKey = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.sapvptiertagger.open_profile",
			GLFW.GLFW_KEY_G,
			class_304.class_11900.field_62556
		));
		openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.sapvptiertagger.open_config",
			GLFW.GLFW_KEY_O,
			class_304.class_11900.field_62556
		));

		ClientCommandRegistrationCallback.EVENT.register(SapvpClientCommands::register);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			profileService.tick(client);

			while (openProfileKey.method_1436()) {
				openLookTargetProfile(client, true);
			}

			while (openConfigKey.method_1436()) {
				openConfigScreen();
			}

			if (pendingUiAction != null) {
				if (pendingUiDelayTicks > 0) {
					pendingUiDelayTicks--;
				} else {
					Runnable action = pendingUiAction;
					pendingUiAction = null;
					action.run();
				}
			}
		});
	}

	public static ConfigManager getConfigManager() {
		return configManager;
	}

	public static SapvpTierTaggerConfig config() {
		return configManager.get();
	}

	public static SapvpProfileService profileService() {
		return profileService;
	}

	public static SapvpAvatarService avatarService() {
		return avatarService;
	}

	public static void saveConfig() {
		configManager.save();
	}

	public static boolean shouldRunInCurrentWorld(class_310 client) {
		if (client.field_1687 == null) {
			return false;
		}
		return !config().onlyInMultiplayer || client.method_1558() != null;
	}

	public static void openLookTargetProfile(class_310 client, boolean notifyOnMiss) {
		class_742 target = getLookedAtPlayer(client);
		if (target == null) {
			if (notifyOnMiss && client.field_1724 != null) {
				client.field_1724.method_7353(class_2561.method_43470("Olhe para um jogador ou use /sapvp info <nick>."), true);
			}
			return;
		}

		openProfile(PlayerLookupTarget.forUuid(target.method_5667(), target.method_5477().getString()));
	}

	public static void openProfile(PlayerLookupTarget target) {
		class_310 client = class_310.method_1551();
		queueUiAction(() -> {
			if (target.uuid() != null) {
				profileService.requestProfile(target.uuid(), target.displayName());
			} else if (target.displayName() != null && !target.displayName().isBlank()) {
				profileService.requestProfileByName(target.displayName());
			}

			client.method_1507(new SapvpInfoScreen(client.field_1755, target));
		});
	}

	public static void openProfile(UUID uuid, String name) {
		openProfile(PlayerLookupTarget.forUuid(uuid, name));
	}

	public static void openProfileByName(String name) {
		openProfile(PlayerLookupTarget.forName(name));
	}

	public static void openMainMenu() {
		class_310 client = class_310.method_1551();
		queueUiAction(() -> client.method_1507(new SapvpMainScreen(client.field_1755)));
	}

	public static void openConfigScreen() {
		class_310 client = class_310.method_1551();
		queueUiAction(() -> client.method_1507(SapvpConfigScreen.create(client.field_1755)));
	}

	@Nullable
	public static class_742 getLookedAtPlayer(class_310 client) {
		if (client.field_1692 instanceof class_742 player) {
			return player;
		}
		return null;
	}

	private static void queueUiAction(Runnable action) {
		pendingUiAction = action;
		pendingUiDelayTicks = 1;
	}
}
