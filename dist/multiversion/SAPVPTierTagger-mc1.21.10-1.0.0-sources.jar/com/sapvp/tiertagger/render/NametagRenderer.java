package com.sapvp.tiertagger.render;

import com.sapvp.tiertagger.SAPVPTierTaggerClient;
import com.sapvp.tiertagger.config.SapvpTierTaggerConfig;
import com.sapvp.tiertagger.model.SapvpModeRanking;
import com.sapvp.tiertagger.model.SapvpPlayerProfile;
import com.sapvp.tiertagger.util.ModeVisuals;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.joml.Matrix4f;

import java.util.Optional;

public final class NametagRenderer {
	private NametagRenderer() {
	}

	public static void render(WorldRenderContext context) {
		class_310 client = class_310.method_1551();
		SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
		if (!config.enabled || !config.renderNametags || !SAPVPTierTaggerClient.shouldRunInCurrentWorld(client)) {
			return;
		}
		if (client.field_1687 == null || client.field_1724 == null || context.gameRenderer() == null || context.matrices() == null) {
			return;
		}

		class_327 textRenderer = client.field_1772;
		class_4587 matrices = context.matrices();
		class_243 cameraPos = context.gameRenderer().method_19418().method_71156();
		class_4597.class_4598 vertices = client.method_22940().method_23000();

		double maxDistanceSq = (double) config.maxRenderDistance * config.maxRenderDistance;
		for (class_742 player : client.field_1687.method_18456()) {
			if (player == client.field_1724 || player.method_5767()) {
				continue;
			}
			if (player.method_5858(client.field_1724) > maxDistanceSq) {
				continue;
			}

			SAPVPTierTaggerClient.profileService().requestProfile(player.method_5667(), player.method_5477().getString());
			Optional<SapvpPlayerProfile> profileResult = SAPVPTierTaggerClient.profileService().getCached(player.method_5667());
			if (profileResult.isEmpty()) {
				continue;
			}

			SapvpPlayerProfile profile = profileResult.get();
			renderTag(textRenderer, matrices, vertices, cameraPos, player, profile, config);
		}

		vertices.method_22993();
	}

	private static void renderTag(
		class_327 textRenderer,
		class_4587 matrices,
		class_4597.class_4598 vertices,
		class_243 cameraPos,
		class_742 player,
		SapvpPlayerProfile profile,
		SapvpTierTaggerConfig config
	) {
		double x = player.method_23317() - cameraPos.field_1352;
		double y = player.method_23318() - cameraPos.field_1351 + player.method_17682() + config.nametagYOffset;
		double z = player.method_23321() - cameraPos.field_1350;

		SapvpModeRanking nametagRanking = profile.nametagRanking(config.nametagMode);
		String tagIcon = config.showModeIconInNametag
			? "[" + ModeVisuals.nametagToken(nametagRanking.modeId()) + "] "
			: config.showDiamondIcon ? "\u2666 " : "";
		String tier = config.nametagFormat.replace("%tier%", nametagRanking.tier().shortLabel());
		String tagText = tagIcon + tier;
		String separator = " | ";
		String name = profile.name();

		int tagTextWidth = textRenderer.method_1727(tagText);
		int separatorWidth = textRenderer.method_1727(separator);
		int nameWidth = textRenderer.method_1727(name);
		float totalWidth = config.hideVanillaNametags
			? tagTextWidth + separatorWidth + nameWidth
			: tagTextWidth;

		matrices.method_22903();
		matrices.method_22904(x, y, z);
		matrices.method_22907(class_310.method_1551().field_1773.method_19418().method_23767());
		float scale = 0.025F * config.nametagScale;
		matrices.method_22905(-scale, -scale, scale);

		Matrix4f positionMatrix = matrices.method_23760().method_23761();
		float drawX = config.hideVanillaNametags
			? -totalWidth / 2.0F
			: -(nameWidth / 2.0F) - tagTextWidth - 6.0F;
		int light = config.showThroughWalls
			? class_765.field_32767
			: class_761.method_23794(player.method_73183(), player.method_24515());
		class_327.class_6415 layerType = config.showThroughWalls
			? class_327.class_6415.field_33994
			: class_327.class_6415.field_33993;

		int tagColor = config.showModeIconInNametag ? ModeVisuals.accentColor(nametagRanking.modeId()) : config.tierColor;
		int tagBackground = tintedBackground(tagColor, config.showThroughWalls ? 0x55 : 0x33);
		textRenderer.method_27521(tagText, drawX, 0, tagColor, true, positionMatrix, vertices, layerType, tagBackground, light);

		if (config.hideVanillaNametags) {
			drawX += tagTextWidth;
			textRenderer.method_27521(separator, drawX, 0, config.separatorColor, true, positionMatrix, vertices, layerType, tintedBackground(config.separatorColor, 0x22), light);
			drawX += separatorWidth;
			textRenderer.method_27521(name, drawX, 0, config.nameColor, true, positionMatrix, vertices, layerType, tintedBackground(config.nameColor, 0x1E), light);
		}

		matrices.method_22909();
	}

	private static int tintedBackground(int color, int alpha) {
		return (alpha << 24) | (color & 0x00FFFFFF);
	}
}

