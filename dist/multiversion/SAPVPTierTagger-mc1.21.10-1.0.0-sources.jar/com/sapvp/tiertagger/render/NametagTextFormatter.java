package com.sapvp.tiertagger.render;

import com.sapvp.tiertagger.SAPVPTierTaggerClient;
import com.sapvp.tiertagger.config.SapvpTierTaggerConfig;
import com.sapvp.tiertagger.model.SapvpModeRanking;
import com.sapvp.tiertagger.model.SapvpPlayerProfile;
import com.sapvp.tiertagger.util.ModeVisuals;
import com.sapvp.tiertagger.util.NametagSideOption;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public final class NametagTextFormatter {
	private NametagTextFormatter() {
	}

	public static class_2561 format(class_1297 player, class_2561 original) {
		class_310 client = class_310.method_1551();
		SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
		if (client.field_1724 != null && player != client.field_1724) {
			double maxDistanceSq = (double) config.maxRenderDistance * config.maxRenderDistance;
			if (player.method_5858(client.field_1724) > maxDistanceSq) {
				return original;
			}
		}

		return format(player.method_5667(), player.method_5477().getString(), original);
	}

	public static class_2561 format(UUID uuid, String fallbackName, class_2561 original) {
		class_310 client = class_310.method_1551();
		SapvpTierTaggerConfig config = SAPVPTierTaggerClient.config();
		if (!config.enabled || !config.renderNametags || !SAPVPTierTaggerClient.shouldRunInCurrentWorld(client)) {
			return original;
		}

		SAPVPTierTaggerClient.profileService().requestProfile(uuid, fallbackName);
		Optional<SapvpPlayerProfile> cached = SAPVPTierTaggerClient.profileService().getCached(uuid);
		if (cached.isEmpty() && fallbackName != null && !fallbackName.isBlank()) {
			cached = SAPVPTierTaggerClient.profileService().getCached(fallbackName);
		}
		if (cached.isEmpty()) {
			return original;
		}

		SapvpModeRanking ranking = cached.get().nametagRanking(config.nametagMode);
		if (ranking.tier().raw() <= 0) {
			return original;
		}

		class_5250 tag = class_2561.method_43473();
		String icon = "";
		if (config.showModeIconInNametag) {
			icon = modeGlyph(ranking.modeId(), config.modeIconStyle);
		} else if (config.showDiamondIcon) {
			icon = "\u2726";
		}

		if (!icon.isBlank()) {
			tag.method_10852(iconText(icon, config.modeIconColor, config.modeIconStyle));
			tag.method_10852(class_2561.method_43470(" "));
		}

		tag.method_10852(class_2561.method_43470(config.nametagFormat.replace("%tier%", ranking.tier().shortLabel()))
			.method_10862(color(config.tierColorFor(ranking.tier()))));

		if (NametagSideOption.fromId(config.nametagSide) == NametagSideOption.RIGHT) {
			return class_2561.method_43473()
				.method_10852(original.method_27661())
				.method_10852(class_2561.method_43470(" | ").method_10862(color(config.separatorColor)))
				.method_10852(tag);
		}

		return class_2561.method_43473()
			.method_10852(tag)
			.method_10852(class_2561.method_43470(" | ").method_10862(color(config.separatorColor)))
			.method_10852(original.method_27661());
	}

	private static class_2583 color(int color) {
		return class_2583.field_24360.method_36139(color & 0x00FFFFFF);
	}

	private static String modeGlyph(String rawMode, String iconStyle) {
		if ("EMOJI".equalsIgnoreCase(iconStyle)) {
			return ModeVisuals.emoji(rawMode);
		}
		return ModeVisuals.iconGlyph(rawMode);
	}

	private static class_2561 iconText(String glyph, int color, String iconStyle) {
		if ("EMOJI".equalsIgnoreCase(iconStyle)) {
			return class_2561.method_43470(glyph).method_10862(color(color));
		}
		return class_2561.method_43470(glyph).method_10862(ModeVisuals.saNametagIconStyle(color));
	}
}
