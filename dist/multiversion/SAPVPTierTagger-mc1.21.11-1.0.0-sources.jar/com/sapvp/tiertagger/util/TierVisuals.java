package com.sapvp.tiertagger.util;

import com.sapvp.tiertagger.SAPVPTierTaggerClient;

public final class TierVisuals {
	private TierVisuals() {
	}

	public static int accentColor(TierLabel tier) {
		if (tier == null || tier.raw() <= 0) {
			return 0xFF6C7086;
		}

		try {
			return SAPVPTierTaggerClient.config().tierColorFor(tier);
		} catch (RuntimeException ignored) {
			return defaultAccentColor(tier);
		}
	}

	public static int backgroundColor(TierLabel tier) {
		int color = accentColor(tier);
		return 0x44000000 | (color & 0x00FFFFFF);
	}

	private static int defaultAccentColor(TierLabel tier) {
		return switch (tier.raw()) {
			case 10 -> 0xFFFFD54A;
			case 9 -> 0xFFE0B848;
			case 8 -> 0xFF8BE07B;
			case 7 -> 0xFF66C25B;
			case 6 -> 0xFF6FE6E1;
			case 5 -> 0xFF41C7C2;
			case 4 -> 0xFF78B8FF;
			case 3 -> 0xFF4A8FE8;
			case 2 -> 0xFFC7B8FF;
			case 1 -> 0xFF8D85B8;
			default -> 0xFFA6ADC8;
		};
	}
}
