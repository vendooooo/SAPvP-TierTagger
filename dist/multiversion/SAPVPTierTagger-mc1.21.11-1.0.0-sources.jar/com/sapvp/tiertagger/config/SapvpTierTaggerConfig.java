package com.sapvp.tiertagger.config;

import com.sapvp.tiertagger.util.ModeVisuals;
import com.sapvp.tiertagger.util.ModeIconStyleOption;
import com.sapvp.tiertagger.util.NametagSideOption;
import com.sapvp.tiertagger.util.TierLabel;

public final class SapvpTierTaggerConfig {
	public boolean enabled = true;
	public boolean renderNametags = true;
	public boolean hideVanillaNametags = false;
	public boolean onlyInMultiplayer = true;
	public boolean showThroughWalls = true;
	public boolean showDiamondIcon = true;
	public boolean showModeIconInNametag = true;
	public String modeIconStyle = "SA_ICONS";
	public int cacheCooldownSeconds = 20;
	public int nearbyRefreshTicks = 80;
	public int requestRadius = 64;
	public int maxTrackedPlayers = 32;
	public int maxRenderDistance = 96;
	public float nametagYOffset = 0.55F;
	public float nametagScale = 1.0F;
	public int diamondColor = 0xFFFFFFFF;
	public int modeIconColor = 0xFFFFFFFF;
	public int tierColor = 0xFFFFD54A;
	public int separatorColor = 0xFFB7C0CC;
	public int nameColor = 0xFFFFFFFF;
	public String nametagFormat = "%tier%";
	public String nametagMode = "BEST";
	public String nametagSide = "LEFT";
	public int ht1Color = 0xFFFFD54A;
	public int lt1Color = 0xFFE0B848;
	public int ht2Color = 0xFF8BE07B;
	public int lt2Color = 0xFF66C25B;
	public int ht3Color = 0xFF6FE6E1;
	public int lt3Color = 0xFF41C7C2;
	public int ht4Color = 0xFF78B8FF;
	public int lt4Color = 0xFF4A8FE8;
	public int ht5Color = 0xFFC7B8FF;
	public int lt5Color = 0xFF8D85B8;

	public long cooldownMillis() {
		return Math.max(2, cacheCooldownSeconds) * 1000L;
	}

	public void normalize() {
		nametagMode = ModeVisuals.normalizeNametagMode(nametagMode);
		nametagSide = NametagSideOption.fromId(nametagSide).id();
		modeIconStyle = ModeIconStyleOption.fromId(modeIconStyle).id();
		normalizeColors();
	}

	public void normalizeColors() {
		diamondColor = ensureAlpha(diamondColor);
		modeIconColor = ensureAlpha(modeIconColor == 0 ? diamondColor : modeIconColor);
		tierColor = ensureAlpha(tierColor);
		separatorColor = ensureAlpha(separatorColor);
		nameColor = ensureAlpha(nameColor);
		ht1Color = ensureAlpha(ht1Color);
		lt1Color = ensureAlpha(lt1Color);
		ht2Color = ensureAlpha(ht2Color);
		lt2Color = ensureAlpha(lt2Color);
		ht3Color = ensureAlpha(ht3Color);
		lt3Color = ensureAlpha(lt3Color);
		ht4Color = ensureAlpha(ht4Color);
		lt4Color = ensureAlpha(lt4Color);
		ht5Color = ensureAlpha(ht5Color);
		lt5Color = ensureAlpha(lt5Color);
	}

	public int tierColorFor(TierLabel tier) {
		if (tier == null || tier.raw() <= 0) {
			return tierColor;
		}

		return switch (tier.shortLabel()) {
			case "HT1" -> ht1Color;
			case "LT1" -> lt1Color;
			case "HT2" -> ht2Color;
			case "LT2" -> lt2Color;
			case "HT3" -> ht3Color;
			case "LT3" -> lt3Color;
			case "HT4" -> ht4Color;
			case "LT4" -> lt4Color;
			case "HT5" -> ht5Color;
			case "LT5" -> lt5Color;
			default -> tierColor;
		};
	}

	private static int ensureAlpha(int color) {
		return (color & 0xFF000000) == 0 ? color | 0xFF000000 : color;
	}
}
